LS,


All sources work both in Delphi 2009 and Delphi 2007.
For Delphi 2007, you will have to create new project files.

To get started, you first have to build and install this package:
NullableComponentsPackage.dpk

Then you can enjoy the rest.

Have fun with it, and please let me know what you are using it form.


Regards,

Jeroen Pluimers
better office benelux
jpluimers@better-office.com