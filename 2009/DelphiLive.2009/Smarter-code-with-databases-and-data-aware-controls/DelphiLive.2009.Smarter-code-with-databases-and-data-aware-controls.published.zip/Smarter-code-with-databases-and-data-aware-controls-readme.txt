LS,


Most sources should work from Delphi 5 to Delphi 2009.
Howver, since class helpers only got introduced recently, they should work from Delphi 2005 upward.

All sources have been used most recently in Delphi 2009, so that works :-)

When using the sources, first build the package (or the whole projectgroup) in the prj directory.

After that you will be able to use the rest.


Have fun with it, and let me know what kind of things you are doing with the sources!


Regards,


Jeroen W. Pluimers - principal consultant
better office benelux
Pyrenee�n 71
1060 NP  Amsterdam
The Netherlands
Tel: +31 (20) 620 83 72
Fax: +31 (20) 620 83 74
http://www.better-office.nl



