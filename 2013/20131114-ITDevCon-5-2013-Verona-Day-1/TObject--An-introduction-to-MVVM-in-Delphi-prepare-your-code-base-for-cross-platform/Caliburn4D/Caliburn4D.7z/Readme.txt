------------------------------------------------------------------------------------------------------------------------------------------

Caliburn.Micro for Delphi 

is a small, yet powerful framework, designed for building applications across all major Delphi Platforms (XE,XE2,XE3). With strong support
for MVVM and other proven UI patterns, Caliburn.Micro will enable you to build your solution quickly, without the need to sacrifice code
quality or testability.

Brief list of features:

- Action Conventions
- Binding Conventions
- Screens and Conductors
- Event Aggregator
- Coroutines
- ViewLocator
- WindowManager
- PropertyChangedBase and BindableCollection
- Bootstrapper
- Logging
- MVVM and MVP

------------------------------------------------------------------------------------------------------------------------------------------